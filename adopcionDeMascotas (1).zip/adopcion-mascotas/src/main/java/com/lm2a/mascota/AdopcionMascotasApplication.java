package com.lm2a.mascota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdopcionMascotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdopcionMascotasApplication.class, args);
	}

}
