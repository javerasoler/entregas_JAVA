package com.lm2a.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdopcionMascotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
