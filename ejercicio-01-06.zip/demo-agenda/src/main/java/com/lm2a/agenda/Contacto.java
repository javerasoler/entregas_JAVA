package com.lm2a.agenda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Contacto {


	//INSERTAR

	public static String INSERT_CONTACTO = "INSERT INTO contactos (id,name,email,tlfn) VALUES(?,?,?,?);";

	public void insertRecord(int id, String name, String email, String tlfn) {
		Connection connection = H2ConnectionUtil.getConnection();

		try {
			PreparedStatement preparedStatement = connection.prepareCall(INSERT_CONTACTO);
			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, name);
			preparedStatement.setString(3, email);
			preparedStatement.setString(4, tlfn);

			System.out.println("INSERTADO: " + id + " " + name + " " + email + " " + tlfn);
			preparedStatement.execute();
			connection.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	//LEER

	public static String READ_CONTACTO = "SELECT id, name, email, tlfn FROM contactos WHERE id = ?";

	public void readRecord(int id_user) {

		Connection connection = H2ConnectionUtil.getConnection();

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(READ_CONTACTO);
			preparedStatement.setInt(1, id_user);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String tlfn = rs.getString("tlfn");

				System.out.println(id + " " + name + " " + email + " " + tlfn);
			}

			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	// LEER TODOS LOS CONTACTOS

	public static String READ_ALL_CONTACTOS = "SELECT * FROM CONTACTOS";

	public void readAllRecords() {

		Connection connection = H2ConnectionUtil.getConnection();
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(READ_ALL_CONTACTOS);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String tlfn = rs.getString("tlfn");

				System.out.println(id + " " + name + " " + email + " " + tlfn);
			}

			connection.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
