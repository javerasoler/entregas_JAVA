package com.lm2a.agenda;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class H2CreateTable {

	public static String CREATE_TABLE_SQL = "CREATE TABLE contactos (" + "id IDENTITY," + "name VARCHAR(20),"
			+ "email VARCHAR(20)," + "tlfn VARCHAR(20));";

	public static void main(String[] args) {
		H2CreateTable h2createTable = new H2CreateTable();
		h2createTable.createTable();
	}

	public void createTable() {
		Connection connection = H2ConnectionUtil.getConnection();

		try {
			Statement statement = connection.createStatement();
			statement.execute(CREATE_TABLE_SQL);
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

//
//Se trata de crear una agenda
//
//Los datos de cada Contacto seran los siguientes:
//
//Contacto[id, nombre, email, telefono]
//
//Crearan una clase que tendra diferentes metodos para cada opcion de CRUD
//
//1. Create, donde le pasaran los datos del Contacto
//2. Read, obtener los datos de un contacto por uno de sus campos (id, nombre, etc.)
//3. Read, obtener todos los Contactos (no se requiere ningun dato adicional)
