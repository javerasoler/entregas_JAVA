package com.lm2a.agenda;

import java.util.Scanner;

public class Main {
	

	public static void main(String[] args) {
		
		Contacto contacto = new Contacto();
		System.out.println("1. Introduce un contacto\n2. Busca un contacto\n3. Busca todos los contactos\n");
		
		Scanner input = new Scanner(System.in);
	
		int flag = input.nextInt();
		// int flag = 3; //Coger del teclado 
		
		switch(flag) {
		case 1:
			
			System.out.println("Introduce el ID: ");
			int id = input.nextInt();
			System.out.println("Introduce el nombre: ");
			String name = input.next();
			System.out.println("Introduce el email: ");
			String email = input.next();
			System.out.println("Introduce el teléfono: ");
			String tlfn = input.next();
			
			contacto.insertRecord(id, name, email, tlfn);
			break;
			
		case 2:
			System.out.println("Introduce el ID: ");
			int id2 = input.nextInt();
			System.out.println("El contacto es de: ");
			contacto.readRecord(id2);
			break;
			
		case 3:
			
			System.out.println("La lista de todos los contactos es la siguiente:\n");
			contacto.readAllRecords();
			break;
			
		default:
			//Sale del switch
			break;
		}

		
		
	}

}
