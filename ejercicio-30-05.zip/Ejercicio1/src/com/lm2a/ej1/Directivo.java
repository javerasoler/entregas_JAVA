package com.lm2a.ej1;

public class Directivo extends Empleado{

	private String area;
	private int vh; //Precio de hora trabajada

	
	// Getters y setters
	
	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	
	
	// Funciones
	
	public Directivo(String nombre, String area) {
		super(nombre);
		this.area = area;
		vh = 12;
	}

	@Override
	public String toString() {
		return "Directivo [area=" + area + ", nombre=" + getNombre() + "]";
	}

	@Override
	public int calcularSalario(int ht) {
		return ht * vh;
		
	}

	
	
	
}
