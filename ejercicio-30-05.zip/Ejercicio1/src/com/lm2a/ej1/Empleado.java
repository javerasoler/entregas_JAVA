package com.lm2a.ej1;

public abstract class Empleado {

	// Clase abstacta: eres t�cnico o directivo

	private String nombre;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + "]";
	}

	public Empleado(String nombre) {
		super();
		this.nombre = nombre;
	}

	
	//Obligar a las clases heredadas a calcular salario
	public abstract int calcularSalario(int ht);
	
}
