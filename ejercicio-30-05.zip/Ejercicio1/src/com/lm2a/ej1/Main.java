package com.lm2a.ej1;

public class Main {

	public static void main(String[] args) {
		
		//Directivos		
		Directivo directivo1 = new Directivo("Juan", "Software");
		Directivo directivo2 = new Directivo("Pepe", "Consultor�a");
		
		//No se crean las clases crean las clases Empleado y T�cnico ya que
		//son clases abstractas que no se pueden crear
		
		
		//Oficiales
		Oficial oficial1 = new Oficial("Jose", "A65F4", "Subcontratado");
		Oficial oficial2 = new Oficial("Rafael", "A09J7", "Fijo");
		
		//Operario
		Operario operario1 = new Operario("Joaquin", "A98HA", "Taladro");
		Operario operario2 = new Operario("Cristina", "A78UT", "Excavadora");

		
		System.out.println(directivo1.toString() + " y " + directivo2.toString());
		System.out.println(oficial1.toString() + " y " + oficial2.toString());
		System.out.println(operario1.toString() + " y " + operario2.toString());
		
		
		//Apartado 4: calcular salario
		
		//Salario calculado para 8 horas trabajadas
		int salario_dir1 = directivo1.calcularSalario(8); 
		int salario_of1 = oficial1.calcularSalario(8); 
		int salario_op1 = operario1.calcularSalario(8);
		
		System.out.println(directivo1.getNombre() + " ha cobrado " + String.valueOf(salario_dir1) + "�");
		System.out.println(oficial1.getNombre() + " ha cobrado " + String.valueOf(salario_of1) + "�");
		System.out.println(operario1.getNombre() + " ha cobrado " + String.valueOf(salario_op1) + "�");

		
		
	}


}
