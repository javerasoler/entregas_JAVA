package com.lm2a.ej1;

public class Oficial extends Tecnico{
	
	//Un oficial es un t�cnico

	private String categoria;
	private int vh; //Precio de la hora trabajada

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Oficial(String nombre, String codigoTaller, String categoria) {
		super(nombre, codigoTaller);
		this.categoria = categoria;
		vh = 10;
	}

	@Override
	public String toString() {
		return "Oficial [categoria=" + categoria + ", codigoTaller=" + getCodigoTaller() + ", nombre=" + getNombre() + "]";
	}

	@Override
	public int calcularSalario(int ht) {
		return ht * vh;
	}
	

}
