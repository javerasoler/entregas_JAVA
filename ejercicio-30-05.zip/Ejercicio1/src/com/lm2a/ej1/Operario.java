package com.lm2a.ej1;

public class Operario extends Tecnico{
	
	//Un operario es un t�cnico

	String maquina;
	private int vh; //Precio de la hora trabajada

	public String getMaquina() {
		return maquina;
	}

	public void setMaquina(String maquina) {
		this.maquina = maquina;
	}

	public Operario(String nombre, String codigoTaller, String maquina) {
		super(nombre, codigoTaller);
		this.maquina = maquina;
		vh = 9;
	}

	@Override
	public String toString() {
		return "Operario [maquina=" + maquina + ", codigoTaller=" + getCodigoTaller() + ", nombre=" + getNombre() + "]";
	}

	@Override
	public int calcularSalario(int ht) {
		return ht * vh;
	}
	
	

}
