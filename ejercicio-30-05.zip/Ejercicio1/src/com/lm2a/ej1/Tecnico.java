package com.lm2a.ej1;

public abstract class Tecnico extends Empleado{
	
	//Clase abstracta: eres oficial o operario

	private String codigoTaller;

	public String getCodigoTaller() {
		return codigoTaller;
	}

	public void setCodigoTaller(String codigoTaller) {
		this.codigoTaller = codigoTaller;
	}

	public Tecnico(String nombre, String codigoTaller) {
		super(nombre);
		this.codigoTaller = codigoTaller;
	}

	@Override
	public String toString() {
		return "Tecnico [codigoTaller=" + codigoTaller + ", nombre=" + getNombre() + "]";
	}
	
}
