package com.lm2a.mavenproject;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		int n = 10; // num de Users
		int cont = 1; // contador de categoria

		ArrayList<User> usuarios = new ArrayList<User>();

		// Crear 10 usuarios
		for (int i = 0; i <= n; i++) {

			if (cont >= 4) {
				cont = 1;
			}

			User user_new = new User((long) i, "Alias"+ Integer.toString(i), "ApellidoComun" + Integer.toString(i), cont);
			usuarios.add(user_new);
			cont = cont + 1;
		}

		// Cambiar categoria dependiendo del sueldo

		int categoria_usuario = 0;

		for (int i = 0; i <= n; i++) {

			categoria_usuario = usuarios.get(i).getCategoria();
			
			switch (categoria_usuario) {
			
			case 2:
				double sueldo = usuarios.get(i).getSueldoBase();
				usuarios.get(i).setSueldoBase(sueldo + (sueldo * 1.3));
				break;

			case 3:
				double sueldo1 = usuarios.get(i).getSueldoBase();
				usuarios.get(i).setSueldoBase(sueldo1 + (sueldo1 * 1.35) + (sueldo1 * 0.32));
				break;

			default:
				//Se queda igual
				break;
			}
		}

		// Imprimir los usuarios

		for (int i = 0; i <= n; i++) {
			System.out.println(usuarios.get(i).toString());
		}
	}

}
