package com.lm2a.mavenproject;

public class User {
	private Long id;
	private String firstName;
	private String lastName;
	private int categoria;
	private double sueldoBase;

	public User(Long id, String firstName, String lastName, int categoria) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.categoria = categoria;
		this.sueldoBase = 1000;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public double getSueldoBase() {
		return sueldoBase;
	}

	public void setSueldoBase(double sueldo) {
		this.sueldoBase = sueldo;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", categoria=" + categoria
				+ ", sueldoBase=" + sueldoBase + "]";
	}

	

}
